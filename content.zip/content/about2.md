---
title: 'FAZENDA NOVA GOKULA'
description: ''
imgs: ['/img/templo2b.jpeg']
---
ISKCON - Sociedade Internacional para Consciência de Krishna!!

Todos podem!1111111

Nova Gokula faz parte do circuito turístico da Serra da Mantiqueira, no Vale do Paraíba, e ocupa uma área de 119,5 hectares, um privilegiado espaço de terra na APA (Área de Proteção Ambiental) da Mantiqueira, unidade de conservação do governo federal. É um bioma com nascentes de água e vegetação nativa. 

Desde sua aquisição, já recuperou mais de 50% da vegetação de sua área. É um verdadeiro santuário e patrimônio da diversidade brasileira, qualificando-se para a implantação da ASM-NG (Área de Soltura e Monitoramento de Animais Silvestres de Nova Gokula), homologada pelo IBAMA e SMA-SP (Secretaria de Meio-ambiente de SP). 
