---
title: 'Como chegar'
description: ''
imgs: []
---
### Opções de transporte para a Fazenda Nova Gokula

A Fazenda Nova Gokula situa-se na região rural de Pindamonhangaba/SP, há 25km da cidade. Funciona sábados, domingos e feriados das 10h às 18h.

No Wase, somente digitar "Nova Gokula";

ÔNIBUS MUNICIPAL: Na imagem, a tabela de horários do ônibus da linha 110 - Ribeirão Grande, que atende os trechos: pinda x nova gokula x pinda. Os ônibus municipais para o Bairro do Ribeirão Grande, tem saídas a partir da Praça 7 de Setembro.

Já no ponto final, caminha-se 2km até a fazenda.

Táxi: 12 98892-5630 (Mateus) Ou 12 98127-1063 (Sesalila - Residente de Nova Gokula)

Há uma taxa de contribuição de visitação de R$10,00 por pessoa e crianças até 12 anos pagam R$5,00. Os valores são revertidos para melhorias da estrutura de visitação.

Como chegar de carro: 

[Rota São Paulo x Nova Gokula](https://www.google.com.br/maps/dir/São+Paulo/-22.77376,-45.45961/@-23.160563,-46.032715,401533m/data=!3m1!1e3!4m9!4m8!1m5!1m1!1s0x94ce448183a461d1:0x9ba94b08ff335bae!2m2!1d-46.6395571!2d-23.5557714!1m1!4e1)

[Rota Rio de Janeiro x Nova Gokula](https://www.google.com.br/maps/dir/Rio+de+Janeiro/-22.77376,-45.45961/@-22.9007119,-45.4726089,3143m/data=!3m1!1e3!4m30!4m29!1m25!1m1!1s0x997efe4224b50b:0xf988253c846c59ee!2m2!1d-43.1729351!2d-22.9068394!3m4!1m2!1d-45.2670077!2d-22.8756198!3s0x94ccc2d3f991d101:0x27f3d51968a7f762!3m4!1m2!1d-45.4022092!2d-22.9509784!3s0x94cce5bf18c9d623:0x4daa0a2db387883e!3m4!1m2!1d-45.3655728!2d-22.9325164!3s0x94cce612e19783bf:0x949da0e48f8f02d8!3m4!1m2!1d-45.4618819!2d-22.9779595!3s0x94ccfadb1348d909:0x76257aa9f5b7a3e4!1m1!4e1!3e0)

[São Paulo ou Aeroporto de Garulhos x Pindamonhangaba](http://passaromarron.com.br)

[Rio de Janeiro x Pindamonhangaba](https://viacaosampaio.com.br/)

A Fazenda Nova Gokula é um santuário natural que oferece aos seus visitantes uma variedade de experiências baseadas no princípio de uma vida simples, natural e saudável e também uma área de preservação ambiental com riquíssima biodiversidade. A comunidade foi criada em 1978 com o intuito de desenvolver a prática de vida simples e pensamento elevado.

Estrada Abílio José de Almeida S/N – Ribeirão Grande – Pindamonhangaba-SP.

[Clique aqui para ver as opções de horários de ônibus de Pinda para a Fazenda Nova Gokula](https://www.vivapinda.com.br/linha1/)

<div>
	<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d10386.513998052435!2d-45.46882941330622!3d-22.769403826861133!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94cc8d6e7ee46f0f%3A0xa542f3b15b5b24e8!2sFazenda%20Nova%20Gokula!5e0!3m2!1spt-BR!2sbr!4v1699897715342!5m2!1spt-BR!2sbr" width="400" height="400" style="border:3px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>