---
{
  "title": "Alimentação",
  "files": [
    "content:alimentacao:confrariavegana.md",
    "content:alimentacao:eka.md",
    "content:alimentacao:lanchonetejaganata.md",
    "content:alimentacao:bistro.md"
  ]
}
---
