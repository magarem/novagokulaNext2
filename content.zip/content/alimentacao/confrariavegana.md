---
title: 'Confraria vegana'
description: ''
imgs: ['/img/alimentacao/confrariavegana.jpeg']
---
Espaço Cultural e Restaurante Confraria Vegana

“Ecologia da boca pra dentro”

Situado em ambiente natural, possui um belo panorama de lagos e montanhas, e o mais importante, saborosos pratos da cozinha vegana com um toque da culinária indiana.

O Espaço Cultural oferece atrações, workshops e retiros de imersão durante todo ano, dispondo de facilidades para os visitantes que vão desde atividades gratuitas à pacotes completos que incluem hospedagem e alimentação à valores acessíveis.

Aberto para almoço sábados e domingos das 12h às 16h. Nos feriados abre também para desjejum (das 8h às 10h) e jantar (das 19h às 21h). 
Localização: dentro da fazenda, seguir a estrada de terra após o templo principal

Informações e reservas:
12 99733-4335 (whatsapp/telegram);
