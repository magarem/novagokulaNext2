---
title: 'Festival de domingo na fazenda nova gokula'
description: ''
imgs: ['/img/eventos/festivaldedomingo.jpeg']
---
Passe o dia com os devotos de Krishna!
Todos as domingos das 6h30 às 18h

Gostaria de participar de um domingo recheado de filosofia, alimentação consciente e programas espirituais na associação dos devotos Krishna?

Programação Especial:

6h30 - Vivência com “Meditação Mântrica - Japa Yoga”;
7h00 - Bhajan (cânticos devocionais introspectivos);
7h30 - Cerimônia Govinda e Homenagem ao Mestre, onde cantamos para Krishna e nosso Guru Srila Prabhupada;
8h00 - Palestra e Roda de Conversa sobre a filosofia do Srimad-Bhagavatam (escritura de mantras e revelações dos antigos sábios);
9h00 - Desjejum Comunitário - traga sua oferenda vegana / vegetariana ou simplesmente compareça e congregue conosco;
12h30 e 16h - Kirtan (canto devocional) com oferta de elementos auspiciosos no altar + roda de bate-papo filosófico;

Nas horas livres, você poderá almoçar em nossos restaurantes e lanchonetes que oferecem iguarias do cardápio vegetariano e vegano, como a tradicional coxinha de jaca. Nas lojas do mini shopping você encontra variadas opções de vestuário, artigos, artesanato e decoração. Em um dia de sol, poderá optar por um refrescante banho de rio nas águas cristalinas do Yamuna!

Contato para maiores informações com:
Radha Damodara, Krishna Balarama ou Krishna Kirtan:
12 98209-8300, 11 98187-0617, 12 98306-0318