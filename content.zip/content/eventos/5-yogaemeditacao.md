---
title: 'Trilha ecológia + yoga + almoço consciente'
description: ''
imgs: ['/img/eventos/yogaemeditacao.jpeg']
---
Todos os sábados e domingos a partir das 9h
Mediante reserva
Bom para grupos!

O que inclui?

> 9h - TRILHA ECOLÓGICA para cachoeira com guia e seguro de acidentes pessoais para “trilha dos poços e cachoeira do jacu": com duração de 3h ida e volta. Nível de dificuldade médio. Com poço pra banho. Pode fazer rapel, contratado à parte;

> 16h - AULA DE YOGA E MEDITAÇÃO para iniciantes com dicas de saúde. Práticas de alongamento, pranayama (respiração), asanas (“saudação ao sol”) e meditação de mantras.

> 13h - ALMOÇO CONSCIENTE completo: salada + prato do dia + suco natural + sobremesa; 
= 
r$195 por pessoa
Reservas antecipadas via pix 

12 99733-4335 (whatsapp/telegram)

