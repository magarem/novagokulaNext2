---
title: 'O Tao do yoga'
description: ''
imgs: ['/img/eventos/otaodayoga.jpeg']
---
Uma conexão entre a tradição Védica, o Taoismo e a Psicologia!
Dias 19 a 21 de janeiro de 2024

Com Danilo Rosas (do Espaço Viver – Guaratinguetá/SP);
Local: Fazenda Nova Gokula, Pindamonhangaba/SP

A união de duas grandes filosofias orientais e a psicologia Junguiana. Um momento para se conectar com sua espiritualidade. Filosofia e Práticas de Yoga, Meditação e Qi Gong, um sistema de práticas taoístas para reequilibrar e nutrir a energia Qi, a energia vital. Significa “cultivo da energia vital” e inclui diversos exercícios para o bem-estar físico e espiritual.

Indicado para pessoas que buscam o equilíbrio entre corpo e mente, terapeutas holísticos, professores de yoga, profissionais da área de saúde e bem-estar.

Faça sua reserva aqui:
12 99733-4335 (whatsapp/telegram);

Conteúdo programático, datas, facilidades e valores, peça no whatsapp acima

Você pode pagar em até 12x pela Sympla!

Realização: Espaço Viver e Confraria Vegana
@danilorosas.yoga
@confraria.vegana
@novagokula