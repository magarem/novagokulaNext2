---
title: 'Réveillon 2024'
description: ''
imgs: ['/img/eventos/evento10.jpeg']
---
RÉVEILLOM 2024
Equilíbrio & Espiritualidade na noite de Ano Novo da Fazenda Nova Gokula 

- Ritual de fogo para queima do Karma;
- Ceia lacto-vegetariana e vegana com 15 tipos de preparações diferentes;
- Som de mantras ao vivo durante a ceia do Espaço Radha Krishna!

PROGRAMAÇÃO:
20h às 22h - Ceia de Réveillon no Espaço Radha-Krishna (cozinha comunitária);
22h - Cerimônia de Fogo para queima do Karma - "atraindo bons fluídos para o ano novo" (assento reservado e kit cerimonial) - (no Templo);
23h - Kirtan e dança congregacional até a virada (no Templo - gratuito);

Valores:
Ceia: r$50/individual e r$90/casal;
Cerimônia de fogo: r$150 por pessoa (valor único)

Reservas antecipadas com Madhavi:
13 98183-6796 (wpp)