---
title: 'Retiro de réveillon 2024'
description: ''
imgs: ['/img/eventos/retirodereveillon.jpeg']
---
De 30 de dezembro a 01 de janeiro
OPULENTA CEIA E PROGRAMAÇÃO VARIADA
Com hospedagem e alimentação completa!
Na Fazenda Nova Gokula, Pindamonhangaba/SP

Valores de 1o lote válidos até dia 30/11
Pague em até 12 vezes pela plataforma Sympla

O Espaço Cultural e Restaurante Confraria Vegana oferece 3 dias de retiro de imersão com programação completa, alimentação consciente e hospedagem de 2 pernoites em ambiente natural entre as montanhas da Serra da Mantiqueira.

Opções de participação:
- IMERSÃO de 3 dias com programação + hospedagem + alimentação completa, ou
- DAY USE (programação/dia + desjejum e almoço)

ATRAÇÕES
-Ceia de réveillon;
-Cerimônia de fogo;
-Vivência de yoga e meditação;
-Palestras sobre Astrologia e Yogaterapia;
-Hospedagem em ambiente natural;
-Alimentação consciente;
+ Opção de SPA com terapias e massagens;
+ Opção de trilha ecológica para cachoeira;

NOITE DE RÉVEILLON
-CEIA das 20h às 22h no Restaurante Confraria Vegana - r$150 por pessoa - o buffet inclui 30 variedades de preparações salgadas e doces, sucos, ponche e champanhe sem álcool para brindar o novo ano;
-CERIMÔNIA DE QUEIMA DO KARMA - 22h (opção de assento privilegiado na arena com Kit cerimonial);
-VIRADA COM KIRTAN E DANÇA CONGREGACIONAL - 23h;

Pague em até 12x: https://bit.ly/3QTJr9Q

Informações e reservas: 12 99733-4335 (wpp)
https://wa.me/5512997334335