---
title: 'Altar'
description: ''
imgs: ['/img/homeslideshow/slide12.jpg']
---
Altar