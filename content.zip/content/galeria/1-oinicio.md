---
title: 'O início'
description: ''
imgs: [
    '/img/homeslideshow/slide23.jpg',
    '/img/homeslideshow/slide22.jpg',
    '/img/prabhupada.jpg'
    ]
---
Nos idos dos anos 70 nasce a comunidade