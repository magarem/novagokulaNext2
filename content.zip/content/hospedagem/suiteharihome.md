---
title: 'Suite Hari Home'
description: ''
imgs: ['img/hospedagem/suiteharihome/suite_harihome.jpg']
---
- Terraço panorâmico, belo jardim e bosque com acesso ao rio.
- Ampla sala social com mobília oriental de fino requinte.
- Ambiente onde funciona o Memorial Prabhupada que possui acervo de livros, vídeos e músicas sobre o fundador do movimento Hare Krishna no ocidente.
- Wi-Fi
Valores / Diária
- Individual R$ 195,00.
- Casal R$ 390,00.
- Cama adicional R$ 80,00.
- Não inclui café da manhã.