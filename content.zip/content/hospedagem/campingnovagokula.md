---
title: 'Camping Nova Gokula'
description: ''
imgs: ['img/hospedagem/campingnovagokula/camping.jpg']
---
- Área gramada medindo 200 m2 ao lado do rio.
- Dispõe de banheiros masculino e feminino, sem banho quente.
- Acesso de carro ao local.
- A 300m do templo.
* Não há energia elétrica no local. Trazer lanternas.
Valores / Diária
- Individual R$ 25,00.
- Crianças até 5 anos não pagam, de 6 a 9 anos pagam meia diária.
- Crianças a partir de 10 anos pagam tarifa de adulto.
- Não inclui café da manhã.