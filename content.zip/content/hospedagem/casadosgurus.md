---
title: 'Casa dos gurus'
description: ''
imgs: ['img/hospedagem/casadosgurus/casa_gurus.jpg']
---
- Casa ampla com salão panorâmico.
- Wifi
- Ar condicionado
- Tela contra insetos
- Belo jardim e bosque com acesso ao rio.
- Ideal para quem deseja conforto e privacidade.
- Casa apta para grupos que desejam um espaço arejado, jardim amplo e atividades a beira do rio( Yoga , dança , relaxamento) valor a combinar.
- A 250m do templo.
Valores / Diária
- R$180,00 por pessoa
- Crianças até 5 anos não pagam, de 6 a 12 anos pagam meia.
- Não inclui café da manhã.
** Valores sujeitos a alteração em festivais e feriados
***Para fazer sua reserva entre em contato com Karen (Katyayani) através do email Kakahdg@hotmail.com ou pelo whatsapp (12) 9.9766-7958.