---
title: 'Hospedaria Lótus'
description: ''
textImg: ['img/hospedagem/hospedarialotus/hospedarialotus.jpg']
---
- Todas as três suítes com uma cama de casal e uma de solteiro.
- Roupas de cama e banho.
- Ventilador.
- Wifi.
- Suítes localizadas a partir de 50 metros do templo..
Valores / Diária
- Finais de semana/ Feriados/ Eventos e Festivais.
- 1 pessoa R$ 80,00.
- 2 pessoas R$ 150,00.
- 3 pessoas R$ 210,00.
- Não inclui café da manhã.
- Preços especiais para grupos e longas estadias.
- Preços em dias comuns a combinar.