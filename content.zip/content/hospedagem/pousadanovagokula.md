---
title: 'Pousada Nova Gokula'
description: ''
textImg: ['img/hospedagem/pousadanovagokula/pousada_novagokula.jpg']
---
- Ladeada por rio cristalino, muito verde e jardins.
- Um ambiente confortável e acolhedor.
- A 300m do templo.
Valores / Diária
- Suíte: Individual R$ 100,00 | Casal R$ 150,00.
- Chalé com cozinha: Individual R$ 100,00 | Casal R$ 170,00.
- Quarto: Individual R$ 100,00 | Casal R$ 150,00.
- Crianças pagam taxa.
- **Valores sujeitos a alterações nos festivais e feriados.
- Não inclui café da manhã.

- A pousada conta com cozinha a disposição dos hóspedes.

Reservas para a Pousada Nova Gokula são feitas diretamente com Jayanti (Yolanda).
Contatos:
pousadanovagokula@gmail.com
12 99673-2022 vivo
12 99750-2021 (whatsapp)