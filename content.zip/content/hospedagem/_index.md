---
{
  "title": "Hospedagem",
  "files": [
    "content:hospedagem:casadosgurus.md",
    "content:hospedagem:espacohimalaya.md",
    "content:hospedagem:hospedarialotus.md",
    "content:hospedagem:pousadanovagokula.md",
    "content:hospedagem:suiteharihome.md",
    "content:hospedagem:campingnovagokula.md"
  ]
}
---
Texto