---
title: 'Espaço Himalaya'
description: ''
textImg: ['img/hospedagem/espacohimalaya/himalaya.jpg']
---
- Estrutura ampla.
- Localização privilegiada em meio a mata verdejante.
- Ideal para retiros de grupos e imersões.
- Fácil acesso.
Valores e maiores informações
- Whatsapp: (31) 97164-2918